﻿// Decompiled with JetBrains decompiler
// Type: MapGenerator
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 26BC5964-F2B6-4620-A38B-D4E04CED132B
// Assembly location: D:\Games\CubeBattle\CubeBattle_Data\Managed\Assembly-CSharp.dll

using UnityEngine;

public class MapGenerator : MonoBehaviour
{
  private void Start()
  {
  }

  private void Update()
  {
  }
}
