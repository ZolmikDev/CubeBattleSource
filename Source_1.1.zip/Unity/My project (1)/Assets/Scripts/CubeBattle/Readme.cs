﻿// Decompiled with JetBrains decompiler
// Type: Readme
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 26BC5964-F2B6-4620-A38B-D4E04CED132B
// Assembly location: D:\Games\CubeBattle\CubeBattle_Data\Managed\Assembly-CSharp.dll

using System;
using UnityEngine;

public class Readme : ScriptableObject
{
  public Texture2D icon;
  public string title;
  public Readme.Section[] sections;
  public bool loadedLayout;

  [Serializable]
  public class Section
  {
    public string heading;
    public string text;
    public string linkText;
    public string url;
  }
}
