﻿
using UnityEngine;

public class YT : MonoBehaviour
{
  public string URL;
  public void OnButtonDown() => Application.OpenURL(URL);
}
