﻿// Decompiled with JetBrains decompiler
// Type: Bullet
// Assembly: Assembly-CSharp-firstpass, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F854CF76-F23B-40C3-B0EB-CA9D6F42F62C
// Assembly location: D:\Games\CubeBattle\CubeBattle_Data\Managed\Assembly-CSharp-firstpass.dll

using UnityEngine;

public class Bullet : MonoBehaviour
{
  public PlayerController player;
  public float speed = 5f;
  public float lifetime;
  public float distance  = 100f;
  public int damage;
  public int teamNum;
  public LayerMask whatIsSolid;
  public GameObject destroyEffect;

  private void Start() => this.Invoke("DestroyBullet", this.lifetime);

  private void Update()
  {
    Collider[] colliderArray = Physics.OverlapSphere(this.transform.position, this.distance, (int) this.whatIsSolid);
    for (int index = 0; index < colliderArray.Length; ++index)
    {
      if ((bool) (Object) colliderArray[index].GetComponent<PlayerController>())
                if(colliderArray[index].GetComponent<PlayerController>()!= player)
      {
        PlayerController component = colliderArray[index].GetComponent<PlayerController>();
        if (component.teamNum == 0 || this.teamNum != component.teamNum)
        {
          if (component.lives <= this.damage)
            ++this.player.kills;
          component.ChangeHealth(-this.damage);
        }
        this.DestroyBullet();
        return;
      }
      if ((bool) (Object) colliderArray[index].GetComponent<CubeDurability>())
      {
        colliderArray[index].GetComponent<CubeDurability>().ChangeDurability(-this.damage);
        this.DestroyBullet();
        return;
      }
      if ((bool) (Object) colliderArray[index].GetComponent<Miner>())
      {
        colliderArray[index].GetComponent<Miner>().ChangeDurability(-this.damage);
        ++this.player.minersDestroyed;
        this.DestroyBullet();
        return;
      }
    }
    this.transform.Translate(Vector3.forward * this.speed * Time.deltaTime);
  }

  private void DestroyBullet()
  {
    Object.Instantiate<GameObject>(this.destroyEffect, this.transform.position, Quaternion.identity);
    Object.Destroy((Object) this.gameObject);
  }
}
