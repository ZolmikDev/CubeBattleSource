﻿// Decompiled with JetBrains decompiler
// Type: CubeDurability
// Assembly: Assembly-CSharp-firstpass, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F854CF76-F23B-40C3-B0EB-CA9D6F42F62C
// Assembly location: D:\Games\CubeBattle\CubeBattle_Data\Managed\Assembly-CSharp-firstpass.dll

using UnityEngine;

public class CubeDurability : MonoBehaviour
{
  public GameObject destroyEffect;
  public float durability;
  public Color startColor;
  private Renderer rend;

  private void Start() => this.rend = this.GetComponent<Renderer>();

  public void ChangeDurability(int changeValue)
  {
    this.durability += (float) changeValue;
    this.CheckDurability();
  }

  public void CheckDurability()
  {
    if ((double) this.durability < 1.0)
    {
      Object.Instantiate<GameObject>(this.destroyEffect, this.transform.position, Quaternion.identity);
      Object.Destroy((Object) this.gameObject);
    }
    else
    {
      float num = this.durability - 2f;
      this.rend.material.color = new Color(this.startColor.r - num * 0.02f, this.startColor.g - num * 0.02f, this.startColor.b - num * 0.02f);
    }
  }
}
