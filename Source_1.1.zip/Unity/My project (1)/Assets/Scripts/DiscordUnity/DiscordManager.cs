﻿// Decompiled with JetBrains decompiler
// Type: DiscordManager
// Assembly: Assembly-CSharp-firstpass, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F854CF76-F23B-40C3-B0EB-CA9D6F42F62C
// Assembly location: D:\Games\CubeBattle\CubeBattle_Data\Managed\Assembly-CSharp-firstpass.dll

using DiscordUnity;
using DiscordUnity.API;
using DiscordUnity.State;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

public class DiscordManager : 
  MonoBehaviour,
  IDiscordServerEvents,
  IDiscordInterface,
  IDiscordMessageEvents,
  IDiscordStatusEvents
{
  public string botToken;
  public string ownerNick;
  public int teamNum;
  public DiscordManager.DiscordLogLevel logLevel;
  public List<string> users;
  public PlayerManager manager;
  public int userIndex;
  public int turnNum = 1;
  public bool started;
  private DiscordMessage currentMessage;

  public static DiscordManager Singleton { get; private set; }

  protected virtual void Awake()
  {
    if ((UnityEngine.Object) DiscordManager.Singleton != (UnityEngine.Object) null)
    {
      UnityEngine.Object.Destroy((UnityEngine.Object) this.gameObject);
    }
    else
    {
      DiscordManager.Singleton = this;
      UnityEngine.Object.DontDestroyOnLoad((UnityEngine.Object) this.gameObject);
    }
  }

  private void OnDestroy()
  {
    if (!((UnityEngine.Object) DiscordManager.Singleton == (UnityEngine.Object) this))
      return;
    DiscordAPI.UnregisterEventsHandler((IDiscordInterface) this);
    DiscordAPI.Stop();
    DiscordManager.Singleton = (DiscordManager) null;
  }

  public virtual async void Begin()
  {
    DiscordManager e = this;
    Debug.Log((object) "Starting DiscordUnity ...");
    DiscordAPI.Logger = (DiscordUnity.ILogger) new DiscordManager.DiscordLogger(e.logLevel);
    DiscordAPI.RegisterEventsHandler((IDiscordInterface) e);
    int num = await DiscordAPI.StartWithBot(e.botToken) ? 1 : 0;
    Debug.Log((object) "DiscordUnity started.");
    e.started = true;
  }

  public void Stop() => DiscordAPI.Stop();

  private void Update() => DiscordAPI.Update();

  public async void OnServerJoined(DiscordServer server)
  {
    Debug.Log((object) "hello world");
    RestResult<DiscordMessage> message = await DiscordAPI.CreateMessage("772015084633325580", "Hello World", (string) null, new bool?(false), (object) null, (object) null, (string) null, (object) null);
  }

  public void OnServerUpdated(DiscordServer server)
  {
  }

  public void OnServerLeft(DiscordServer server)
  {
  }

  public void OnServerBan(DiscordServer server, DiscordUser user)
  {
  }

  public void OnServerUnban(DiscordServer server, DiscordUser user)
  {
  }

  public void OnServerEmojisUpdated(DiscordServer server, DiscordEmoji[] emojis)
  {
  }

  public void OnServerMemberJoined(DiscordServer server, DiscordServerMember member)
  {
  }

  public void OnServerMemberUpdated(DiscordServer server, DiscordServerMember member)
  {
  }

  public void OnServerMemberLeft(DiscordServer server, DiscordServerMember member)
  {
  }

  public void OnServerMembersChunk(
    DiscordServer server,
    DiscordServerMember[] members,
    string[] notFound,
    DiscordPresence[] presences)
  {
  }

  public void OnServerRoleCreated(DiscordServer server, DiscordRole role) => Debug.Log((object) ("role added: " + role.Name));

  public void OnServerRoleUpdated(DiscordServer server, DiscordRole role)
  {
  }

  public void OnServerRoleRemove(DiscordServer server, DiscordRole role)
  {
  }

  public async void OnMessageCreated(DiscordMessage message)
  {
    bool? bot = message.Author.Bot;
    if (bot.HasValue)
    {
      bot = message.Author.Bot;
      bool flag = false;
      if (!(bot.GetValueOrDefault() == flag & bot.HasValue))
        goto label_13;
    }
    if (message.Content.Contains("!начать игру") && message.Author.Username == this.ownerNick)
    {
      RestResult<DiscordMessage> message1 = await DiscordAPI.CreateMessage(message.ChannelId, "**CubeBattle** начался! \nСоздатель мода: <@619572625743806464> \nПомощь: <@785148984350998579>, <@574856443581300745>", (string) null, new bool?(false), (object) null, (object) null, (string) null, (object) null);
      await Task.Delay(100);
      Debug.Log((object) "началась игра");
      if (this.teamNum == 0)
      {
        RestResult<DiscordMessage> message2 = await DiscordAPI.CreateMessage(message.ChannelId, "Выбери свой цвет!", (string) null, new bool?(false), (object) null, (object) null, (string) null, (object) null);
      }
      else
      {
        RestResult<DiscordMessage> message3 = await DiscordAPI.CreateMessage(message.ChannelId, "Нажми, чтобы присоединиться!", (string) null, new bool?(false), (object) null, (object) null, (string) null, (object) null);
      }
      await Task.Delay(100);
    }
    if (message.Content.Contains("!стоп") && message.Author.Username == this.ownerNick)
    {
      RestResult<bool> restResult = await DiscordAPI.DeleteMessage(message.ChannelId, this.currentMessage.Id);
      await Task.Delay(100);
      RestResult<DiscordMessage> message4 = await DiscordAPI.CreateMessage(message.ChannelId, "Игра остановлена!", (string) null, new bool?(false), (object) null, (object) null, (string) null, (object) null);
    }
label_13:
    bot = message.Author.Bot;
    bool flag1 = true;
    if (bot.GetValueOrDefault() == flag1 & bot.HasValue && message.Content.Contains("Выбери свой цвет!"))
    {
      this.currentMessage = message;
      RestResult<DiscordMessage> restResult = await DiscordAPI.EditMessage(message.ChannelId, message.Id, "Выбери свой цвет! Осталось **60** сек", (object) null, 0);
      await Task.Delay(100);
      await this.AddEmoji(message.ChannelId, message.Id, "❤️");
      await Task.Delay(100);
      await this.AddEmoji(message.ChannelId, message.Id, "\uD83C\uDF4A");
      await Task.Delay(100);
      await this.AddEmoji(message.ChannelId, message.Id, "\uD83D\uDC9B");
      await Task.Delay(100);
      await this.AddEmoji(message.ChannelId, message.Id, "\uD83D\uDC9A");
      await Task.Delay(100);
      await this.AddEmoji(message.ChannelId, message.Id, "\uD83D\uDC99");
      await Task.Delay(100);
      await this.AddEmoji(message.ChannelId, message.Id, "\uD83D\uDC9C");
      await Task.Delay(100);
      await this.AddEmoji(message.ChannelId, message.Id, "\uD83D\uDC97");
    }
    bot = message.Author.Bot;
    bool flag2 = true;
    if (bot.GetValueOrDefault() == flag2 & bot.HasValue && message.Content.Contains("Нажми, чтобы присоединиться!"))
    {
      this.currentMessage = message;
      RestResult<DiscordMessage> restResult = await DiscordAPI.EditMessage(message.ChannelId, message.Id, "Нажми, чтобы присоединиться! Осталось **60** сек", (object) null, 0);
      await Task.Delay(100);
      await this.AddEmoji(message.ChannelId, message.Id, "▶️");
      await Task.Delay(100);
    }
    bot = message.Author.Bot;
    bool flag3 = true;
    if (bot.GetValueOrDefault() == flag3 & bot.HasValue && message.Content.Contains("Выбери действие"))
      Debug.Log((object) ("Message send: " + message.Content + ", from: " + message.Author.Username + ", messageID: " + message.Id));
    bot = message.Author.Bot;
    bool flag4 = true;
    if (!(bot.GetValueOrDefault() == flag4 & bot.HasValue) || !message.Content.Contains("**——— Ход " + this.turnNum.ToString() + " ———**"))
      return;
    this.currentMessage = message;
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "⬅");
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "➡");
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "⬆");
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "⬇");
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "↩️");
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "↪️");
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "\uD83D\uDCA5");
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "⬜");
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "⛏️");
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "\uD83D\uDC96");
    await Task.Delay(75);
    await this.AddEmoji(message.ChannelId, message.Id, "⏫");
    await Task.Delay(75);
    RestResult<DiscordMessage> restResult1 = await DiscordAPI.EditMessage(message.ChannelId, message.Id, "**——— Ход " + this.turnNum.ToString() + ": **Осталось **7** сек **———**", (object) null, 0);
  }

  public async void OnMessageUpdated(DiscordMessage message)
  {
    await Task.Delay(900);
    if (message.Content.Contains("Выбери свой цвет!"))
    {
      for (int index = 60; index > 0; --index)
      {
        if (message.Content.Contains("Выбери свой цвет! Осталось **" + index.ToString() + "** сек"))
        {
          RestResult<DiscordMessage> restResult = await DiscordAPI.EditMessage(message.ChannelId, message.Id, "Выбери свой цвет! Осталось **" + (index - 1).ToString() + "** сек", (object) null, 0);
          this.manager.MinusSeconds();
          break;
        }
      }
    }
    else if (message.Content.Contains("Нажми, чтобы присоединиться!"))
    {
      for (int index = 60; index > 0; --index)
      {
        if (message.Content.Contains("Нажми, чтобы присоединиться! Осталось **" + index.ToString() + "** сек"))
        {
          RestResult<DiscordMessage> restResult = await DiscordAPI.EditMessage(message.ChannelId, message.Id, "Нажми, чтобы присоединиться! Осталось **" + (index - 1).ToString() + "** сек", (object) null, 0);
          this.manager.MinusSeconds();
          break;
        }
      }
    }
    bool? bot = message.Author.Bot;
    bool flag = true;
    if (bot.GetValueOrDefault() == flag & bot.HasValue && (message.Content.Contains("Выбери свой цвет! Осталось **0** сек") || message.Content.Contains("**——— Ход " + this.turnNum.ToString() + ": **Осталось **0** сек **———**") || message.Content.Contains("Нажми, чтобы присоединиться! Осталось **0** сек")))
    {
      ++this.turnNum;
      RestResult<bool> restResult = await DiscordAPI.DeleteMessage(message.ChannelId, message.Id);
      foreach (PlayerController player in this.manager.players)
        player.UpdateCubes();
      await Task.Delay(100);
      RestResult<DiscordMessage> message1 = await DiscordAPI.CreateMessage(message.ChannelId, "**——— Ход " + this.turnNum.ToString() + " ———**", (string) null, new bool?(false), (object) null, (object) null, (string) null, (object) null);
      await Task.Delay(100);
      this.manager.SpawnBonuses();
      foreach (PlayerController player in this.manager.players)
      {
        player.isBusy = false;
        player.actionNum = 0;
      }
      await Task.Delay(100);
    }
    if (!message.Content.Contains("——— Ход"))
      return;
    for (int index = 11; index > 0; --index)
    {
      if (message.Content.Contains("**——— Ход " + this.turnNum.ToString() + ": **Осталось **" + index.ToString() + "** сек **———**"))
      {
        int num = index - 1;
        RestResult<DiscordMessage> restResult = await DiscordAPI.EditMessage(message.ChannelId, message.Id, "**——— Ход " + this.turnNum.ToString() + ": **Осталось **" + num.ToString() + "** сек **———**", (object) null, 0);
        break;
      }
    }
  }

  public void OnMessageDeleted(DiscordMessage message) => Debug.Log((object) "Message Deleted...");

  public void OnMessageDeletedBulk(string[] messageIds)
  {
  }

  public async void OnMessageReactionAdded(DiscordMessageReaction messageReaction)
  {
    if (messageReaction.Member.User.Bot.HasValue)
    {
      bool? bot = messageReaction.Member.User.Bot;
      bool flag = false;
      if (!(bot.GetValueOrDefault() == flag & bot.HasValue))
        return;
    }
    if (this.users.Contains(messageReaction.UserId))
    {
      for (int index = 0; index < this.users.Count; ++index)
      {
        if (this.users[index] == messageReaction.UserId)
        {
          this.userIndex = index;
          break;
        }
      }
      PlayerController player = this.manager.players[this.userIndex];
      if ((UnityEngine.Object) player != (UnityEngine.Object) null && !player.isBusy && !player.isDead)
      {
        player.canTakeBonus = true;
        if (messageReaction.Emoji.Name == "⬅")
        {
          if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 90.0)
            player.movingLeft = true;
          else if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 0.0)
          {
            player.OnTurnRight();
            await Task.Delay(400);
            player.movingLeft = true;
          }
          else if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 180.0)
          {
            player.OnTurnLeft();
            await Task.Delay(400);
            player.movingLeft = true;
          }
          else
          {
            player.OnTurnLeft();
            await Task.Delay(700);
            player.OnTurnLeft();
            await Task.Delay(400);
            player.movingLeft = true;
          }
          player.MakeAction();
          if (player.readyToUpgrade)
            player.OnAnimDown();
        }
        else if (messageReaction.Emoji.Name == "➡")
        {
          WaitUntil waitUntil = new WaitUntil((Func<bool>) (() => player.isBusy));
          if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 270.0)
            player.movingRight = true;
          else if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 180.0)
          {
            player.OnTurnRight();
            await Task.Delay(400);
            player.movingRight = true;
          }
          else if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 0.0)
          {
            player.OnTurnLeft();
            await Task.Delay(400);
            player.movingRight = true;
          }
          else
          {
            player.OnTurnLeft();
            await Task.Delay(700);
            player.OnTurnLeft();
            await Task.Delay(400);
            player.movingRight = true;
          }
          player.MakeAction();
          if (player.readyToUpgrade)
            player.OnAnimDown();
        }
        else if (messageReaction.Emoji.Name == "⬆")
        {
          WaitUntil waitUntil = new WaitUntil((Func<bool>) (() => player.isBusy));
          if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 180.0)
            player.movingForward = true;
          else if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 90.0)
          {
            player.OnTurnRight();
            await Task.Delay(400);
            player.movingForward = true;
          }
          else if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 270.0)
          {
            player.OnTurnLeft();
            await Task.Delay(400);
            player.movingForward = true;
          }
          else
          {
            player.OnTurnLeft();
            await Task.Delay(700);
            player.OnTurnLeft();
            await Task.Delay(400);
            player.movingForward = true;
          }
          player.MakeAction();
          if (player.readyToUpgrade)
            player.OnAnimDown();
        }
        else if (messageReaction.Emoji.Name == "⬇")
        {
          WaitUntil waitUntil = new WaitUntil((Func<bool>) (() => player.isBusy));
          if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 0.0)
            player.movingBack = true;
          else if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 270.0)
          {
            player.OnTurnRight();
            await Task.Delay(400);
            player.movingBack = true;
          }
          else if ((double) Mathf.Round(player.transform.localEulerAngles.y) == 90.0)
          {
            player.OnTurnLeft();
            await Task.Delay(400);
            player.movingBack = true;
          }
          else
          {
            player.OnTurnLeft();
            await Task.Delay(700);
            player.OnTurnLeft();
            await Task.Delay(500);
            player.movingBack = true;
          }
          player.MakeAction();
          if (player.readyToUpgrade)
            player.OnAnimDown();
        }
        else if (messageReaction.Emoji.Name == "↪️")
        {
          player.OnTurnLeft();
          player.MakeAction();
          if (player.readyToUpgrade)
            player.OnAnimDown();
        }
        else if (messageReaction.Emoji.Name == "↩️")
        {
          player.OnTurnRight();
          if (player.readyToUpgrade)
            player.OnAnimDown();
          player.MakeAction();
        }
        else if (messageReaction.Emoji.Name == "\uD83D\uDCA5")
        {
          if (!player.readyToUpgrade)
            player.Shoot();
          else if (player.readyToUpgrade)
          {
            if (player.damageLvl == 0 && player.cubes >= 5)
            {
              player.ChangeCubes(-5);
              ++player.damageLvl;
              player.Upgrade();
            }
            else if (player.damageLvl == 1 && player.cubes >= 15)
            {
              player.ChangeCubes(-15);
              ++player.damageLvl;
              player.Upgrade();
            }
            else if (player.damageLvl == 2 && player.cubes >= 35)
            {
              player.ChangeCubes(-35);
              ++player.damageLvl;
              player.Upgrade();
            }
            else if (player.damageLvl == 3 && player.cubes >= 75)
            {
              player.ChangeCubes(-75);
              ++player.damageLvl;
              player.Upgrade();
            }
            else if (player.damageLvl == 4 && player.cubes >= 150)
            {
              player.ChangeCubes(-150);
              ++player.damageLvl;
              player.Upgrade();
            }
            else if (player.damageLvl == 5 && player.cubes >= 300)
            {
              player.ChangeCubes(-300);
              ++player.damageLvl;
              player.Upgrade();
            }
            else
              player.OnAnimDown();
          }
          player.MakeAction();
        }
        else if (messageReaction.Emoji.Name == "⬜")
        {
          if (!player.readyToUpgrade)
          {
            player.UpdateColliders();
            await Task.Delay(100);
            player.InstantiateCube();
          }
          else if (player.readyToUpgrade)
          {
            if (player.wallsLvl == 0 && player.cubes >= 15)
            {
              player.ChangeCubes(-15);
              ++player.wallsLvl;
              player.Upgrade();
            }
            else if (player.wallsLvl == 1 && player.cubes >= 75)
            {
              player.ChangeCubes(-75);
              ++player.wallsLvl;
              player.Upgrade();
            }
            else if (player.wallsLvl == 2 && player.cubes >= 150)
            {
              player.ChangeCubes(-150);
              ++player.wallsLvl;
              player.Upgrade();
            }
            else if (player.wallsLvl == 3 && player.cubes >= 300)
            {
              player.ChangeCubes(-300);
              ++player.wallsLvl;
              player.Upgrade();
            }
            else
              player.OnAnimDown();
            player.MakeAction();
          }
        }
        else if (messageReaction.Emoji.Name == "⛏️")
        {
          if (!player.readyToUpgrade)
          {
            player.UpdateColliders();
            await Task.Delay(100);
            player.InstantiateMiner();
          }
          else if (player.readyToUpgrade)
          {
            if (player.minerLvl == 0 && player.cubes >= 5)
            {
              player.ChangeCubes(-5);
              ++player.minerLvl;
              player.Upgrade();
            }
            else if (player.minerLvl == 1 && player.cubes >= 15)
            {
              player.ChangeCubes(-15);
              ++player.minerLvl;
              player.Upgrade();
            }
            else if (player.minerLvl == 2 && player.cubes >= 35)
            {
              player.ChangeCubes(-35);
              ++player.minerLvl;
              player.Upgrade();
            }
            else if (player.minerLvl == 3 && player.cubes >= 75)
            {
              player.ChangeCubes(-75);
              ++player.minerLvl;
              player.Upgrade();
            }
            else if (player.minerLvl == 4 && player.cubes >= 150)
            {
              player.ChangeCubes(-150);
              ++player.minerLvl;
              player.Upgrade();
            }
            else
              player.OnAnimDown();
            player.MakeAction();
          }
        }
        else if (messageReaction.Emoji.Name == "\uD83D\uDC96")
        {
          if (!player.readyToUpgrade)
            player.OnHeal();
          else if (player.readyToUpgrade)
          {
            if (player.healLvl == 0 && player.cubes >= 15)
            {
              player.ChangeCubes(-15);
              ++player.healLvl;
              player.Upgrade();
            }
            else if (player.healLvl == 1 && player.cubes >= 75)
            {
              player.ChangeCubes(-75);
              ++player.healLvl;
              player.Upgrade();
            }
            else if (player.healLvl == 2 && player.cubes >= 200)
            {
              player.ChangeCubes(-200);
              ++player.healLvl;
              player.Upgrade();
            }
            else
              player.OnAnimDown();
          }
          player.MakeAction();
        }
        else if (messageReaction.Emoji.Name == "⏫")
        {
          if (player.readyToUpgrade)
          {
            if (player.actionLvl == 0 && player.cubes >= 15)
            {
              player.ChangeCubes(-15);
              ++player.actionLvl;
              player.Upgrade();
            }
            else if (player.actionLvl == 1 && player.cubes >= 75)
            {
              player.ChangeCubes(-75);
              ++player.actionLvl;
              player.Upgrade();
            }
            else if (player.actionLvl == 2 && player.cubes >= 200)
            {
              player.ChangeCubes(-200);
              ++player.actionLvl;
              player.Upgrade();
            }
            else
              player.OnAnimDown();
          }
          else if (!player.readyToUpgrade)
          {
            player.OnAnimUp();
            player.readyToUpgrade = true;
          }
          player.MakeAction();
        }
      }
    }
    else if (messageReaction.Emoji.Name == "❤️")
    {
      this.users.Add(messageReaction.UserId);
      this.manager.OnNewPlayerSpawn(messageReaction.Member.User.Username, 0);
    }
    else if (messageReaction.Emoji.Name == "\uD83C\uDF4A")
    {
      this.users.Add(messageReaction.UserId);
      this.manager.OnNewPlayerSpawn(messageReaction.Member.User.Username, 1);
    }
    else if (messageReaction.Emoji.Name == "\uD83D\uDC9B")
    {
      this.users.Add(messageReaction.UserId);
      this.manager.OnNewPlayerSpawn(messageReaction.Member.User.Username, 2);
    }
    else if (messageReaction.Emoji.Name == "\uD83D\uDC9A")
    {
      this.users.Add(messageReaction.UserId);
      this.manager.OnNewPlayerSpawn(messageReaction.Member.User.Username, 3);
    }
    else if (messageReaction.Emoji.Name == "\uD83D\uDC99")
    {
      this.users.Add(messageReaction.UserId);
      this.manager.OnNewPlayerSpawn(messageReaction.Member.User.Username, 4);
    }
    else if (messageReaction.Emoji.Name == "\uD83D\uDC9C")
    {
      this.users.Add(messageReaction.UserId);
      this.manager.OnNewPlayerSpawn(messageReaction.Member.User.Username, 5);
    }
    else if (messageReaction.Emoji.Name == "\uD83D\uDC97")
    {
      this.users.Add(messageReaction.UserId);
      this.manager.OnNewPlayerSpawn(messageReaction.Member.User.Username, 6);
    }
    else
    {
      if (!(messageReaction.Emoji.Name == "▶️"))
        return;
      this.users.Add(messageReaction.UserId);
      this.manager.OnTeamPlayerSpawn(messageReaction.Member.User.Username);
    }
  }

  public void OnMessageReactionRemoved(DiscordMessageReaction messageReaction)
  {
  }

  public void OnMessageAllReactionsRemoved(DiscordMessageReaction messageReaction)
  {
  }

  public void OnMessageEmojiReactionRemoved(DiscordMessageReaction messageReaction) => Debug.Log((object) "emoji removed");

  public void OnPresenceUpdated(DiscordPresence presence)
  {
  }

  public void OnTypingStarted(DiscordChannel channel, DiscordUser user, DateTime timestamp) => Debug.Log((object) "started typing");

  public void OnServerTypingStarted(
    DiscordChannel channel,
    DiscordServerMember member,
    DateTime timestamp)
  {
    Debug.Log((object) "started typing");
  }

  public void OnUserUpdated(DiscordUser user)
  {
  }

  private async Task AddEmoji(string ChannelId, string messageId, string emoji)
  {
    RestResult<bool> reaction = await DiscordAPI.CreateReaction(ChannelId, messageId, emoji);
  }

  public enum DiscordLogLevel
  {
    None,
    Error,
    Warning,
    Debug,
  }

  private class DiscordLogger : DiscordUnity.ILogger
  {
    private readonly DiscordManager.DiscordLogLevel level;

    public DiscordLogger(DiscordManager.DiscordLogLevel level) => this.level = level;

    public void Log(string log)
    {
      if (this.level < DiscordManager.DiscordLogLevel.Debug)
        return;
      Debug.Log((object) log);
    }

    public void LogWarning(string log)
    {
      if (this.level < DiscordManager.DiscordLogLevel.Warning)
        return;
      Debug.LogWarning((object) log);
    }

    public void LogError(string log, Exception exception = null)
    {
      if (this.level < DiscordManager.DiscordLogLevel.Error)
        return;
      Debug.LogError((object) log);
      Debug.LogError((object) exception);
    }
  }
}
