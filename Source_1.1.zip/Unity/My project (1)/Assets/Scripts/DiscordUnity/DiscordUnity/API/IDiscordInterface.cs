﻿namespace DiscordUnity.API
{
    public interface IDiscordInterface
    {

    }
}
