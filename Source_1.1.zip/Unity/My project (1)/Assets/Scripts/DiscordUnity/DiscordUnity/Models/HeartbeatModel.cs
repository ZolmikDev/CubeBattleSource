﻿namespace DiscordUnity.Models
{
    internal class HeartbeatModel
    {
        public int HeartbeatInterval { get; set; }
    }
}
