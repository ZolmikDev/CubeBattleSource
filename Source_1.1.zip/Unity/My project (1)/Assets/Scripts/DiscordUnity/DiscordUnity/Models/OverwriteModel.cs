﻿namespace DiscordUnity.Models
{
    internal class OverwriteModel
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public int Allow { get; set; }
        public int Deny { get; set; }
    }
}
