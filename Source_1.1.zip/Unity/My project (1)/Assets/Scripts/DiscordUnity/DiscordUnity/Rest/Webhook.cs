﻿namespace DiscordUnity
{
    public static partial class DiscordAPI
    {

    }
}
