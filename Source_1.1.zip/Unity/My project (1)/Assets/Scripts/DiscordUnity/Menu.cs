﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// Token: 0x0200001D RID: 29
public class Menu : MonoBehaviour
{
	// Token: 0x060000C3 RID: 195 RVA: 0x000053C8 File Offset: 0x000035C8
	private void Awake()
	{
		this.discordManager = UnityEngine.Object.FindObjectOfType<DiscordManager>();
		if (this.sceneNum == 1)
		{
			this.teamText.discordManager = this.discordManager;
			this.discordManager.ownerNick = PlayerPrefs.GetString("nick");
			this.discordManager.botToken = PlayerPrefs.GetString("token");
			this.inputFields[0].text = PlayerPrefs.GetString("nick");
			this.inputFields[1].text = PlayerPrefs.GetString("token");
		}
	}

	// Token: 0x060000C4 RID: 196 RVA: 0x00005454 File Offset: 0x00003654
	public void LoadGame()
	{
		if (this.sceneNum == 1)
		{
			if (!this.discordManager.started)
			{
				this.discordManager.Begin();
			}
		}
		else if (this.sceneNum == 0)
		{
			this.discordManager.started = false;
			this.discordManager.users.Clear();
			this.discordManager.turnNum = 0;
			this.discordManager.teamNum = 0;
			this.discordManager.Stop();
		}
		SceneManager.LoadScene(this.sceneNum);
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x000054D6 File Offset: 0x000036D6
	public void ReadNick(string nick)
	{
		this.discordManager.ownerNick = nick;
		PlayerPrefs.SetString("nick", nick);
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x000054EF File Offset: 0x000036EF
	public void ReadToken(string token)
	{
		this.discordManager.botToken = token;
		PlayerPrefs.SetString("token", token);
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x00005508 File Offset: 0x00003708
	public void ShowRules()
	{
		this.panels[0].SetActive(false);
		this.panels[1].SetActive(true);
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x00005526 File Offset: 0x00003726
	public void ShowMenu()
	{
		this.panels[1].SetActive(false);
		this.panels[0].SetActive(true);
		this.panels[2].SetActive(false);
	}
	public void ShowTitles()
	{
		this.panels[0].SetActive(false);
		this.panels[2].SetActive(true);
	}
	// Token: 0x060000C9 RID: 201 RVA: 0x00005544 File Offset: 0x00003744
	public void ScrollPageLeft()
	{
		if (this.rulesPage > 0)
		{
			this.rulesPage--;
			this.pages[this.rulesPage + 1].SetActive(false);
			this.pages[this.rulesPage].SetActive(true);
			this.ruleText.text = (this.rulesPage + 1).ToString() + "/6";
		}
	}

	// Token: 0x060000CA RID: 202 RVA: 0x000055B8 File Offset: 0x000037B8
	public void ScrollPageRight()
	{
		if (this.rulesPage < 5)
		{
			this.rulesPage++;
			this.pages[this.rulesPage - 1].SetActive(false);
			this.pages[this.rulesPage].SetActive(true);
			this.ruleText.text = (this.rulesPage + 1).ToString() + "/6";
		}
	}

	// Token: 0x04000063 RID: 99
	public DiscordManager discordManager;

	// Token: 0x04000064 RID: 100
	public int sceneNum;

	// Token: 0x04000065 RID: 101
	public int rulesPage;

	// Token: 0x04000066 RID: 102
	public TeamNumChange teamText;

	// Token: 0x04000067 RID: 103
	public Text ruleText;

	// Token: 0x04000068 RID: 104
	public InputField[] inputFields;

	// Token: 0x04000069 RID: 105
	public GameObject[] panels;

	// Token: 0x0400006A RID: 106
	public GameObject[] pages;
}
