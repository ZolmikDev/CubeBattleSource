﻿// Decompiled with JetBrains decompiler
// Type: Miner
// Assembly: Assembly-CSharp-firstpass, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F854CF76-F23B-40C3-B0EB-CA9D6F42F62C
// Assembly location: D:\Games\CubeBattle\CubeBattle_Data\Managed\Assembly-CSharp-firstpass.dll

using System.Collections;
using UnityEngine;

public class Miner : MonoBehaviour
{
  [HideInInspector]
  public PlayerController player;
  public GameObject destroyEffect;
  public GameObject cube;
  public TextMesh levelText;
  public TextMesh levelTextShadow;
  public int lifetime;
  public Color startColor;
  public int durability;
  private int minerLvl;

  public void OnAppear(int level)
  {
    this.minerLvl = level;
    this.levelText.text = "Lvl" + level.ToString();
    this.levelTextShadow.text = "Lvl" + level.ToString();
    this.startColor = this.player.cubeMat.color;
    this.levelText.color = this.startColor;
  }

  private void Update()
  {
    if (!((Object) this.levelText != (Object) null))
      return;
    this.levelText.transform.LookAt(Camera.main.transform.position);
    this.levelText.transform.Rotate(0.0f, 180f, 0.0f);
  }

  public void GiveCubes()
  {
    --this.lifetime;
    if (this.lifetime > 0)
    {
      this.player.ChangeCubes(this.minerLvl);
    }
    else
    {
      if (this.lifetime > 0)
        return;
      this.player.ChangeCubes(this.minerLvl);
      this.StartCoroutine(this.WaitForDestruction());
    }
  }

  public void ChangeDurability(int changeValue)
  {
    this.durability += changeValue;
    this.CheckDurability();
  }

  public void CheckDurability()
  {
    if (this.durability < 0)
    {
      Object.Instantiate<GameObject>(this.destroyEffect, this.transform.position, Quaternion.identity);
      this.player.miners.Remove(this);
      Object.Destroy((Object) this.gameObject);
    }
    else
      this.cube.GetComponent<Renderer>().material.color = new Color(this.startColor.r - (float) this.durability * 0.075f, this.startColor.g - (float) this.durability * 0.075f, this.startColor.b - (float) this.durability * 0.075f);
  }

  private void OnTriggerEnter(Collider other)
  {
    if (!other.CompareTag("Dead"))
      return;
    this.ChangeDurability(-10000);
  }

  public IEnumerator WaitForDestruction()
  {
    yield return (object) new WaitForSeconds(2f);
    this.ChangeDurability(-1);
  }
}
