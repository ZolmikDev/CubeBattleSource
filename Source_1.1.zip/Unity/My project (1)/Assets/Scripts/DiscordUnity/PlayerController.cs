﻿// Decompiled with JetBrains decompiler
// Type: PlayerController
// Assembly: Assembly-CSharp-firstpass, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F854CF76-F23B-40C3-B0EB-CA9D6F42F62C
// Assembly location: D:\Games\CubeBattle\CubeBattle_Data\Managed\Assembly-CSharp-firstpass.dll

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
  [HideInInspector]
  public bool movingRight;
  [HideInInspector]
  public bool movingLeft;
  [HideInInspector]
  public bool movingBack;
  [HideInInspector]
  public bool movingForward;
  public bool isRotating;
  [HideInInspector]
  public bool canTakeBonus = true;
  public bool readyToUpgrade;
  public bool groundIsBehind;
  public bool groundIsForward;
  [Header("PlayerData")]
  public TextMesh nickname;
  public TextMesh nicknameShadow;
  public TextMesh hpText;
  public TextMesh hpTextShadow;
  public TextMesh cubeText;
  public TextMesh cubeTextShadow;
  public TextMesh turnText;
  public TextMesh turnTextShadow;
  public Material cubeMat;
  [Header("Transforms")]
  public Transform groundForwardPos;
  public Transform groundBehindPos;
  public Transform bulletPos;
  public LayerMask whatIsGround;
  public LayerMask whatIsPlayer;
  [Header("Other objects")]
  public GameObject destroyEffect;
  public GameObject healEffect;
  public GameObject upgradeEffect;
  public GameObject midBodyPart;
  public GameObject thirdBodyPart;
  public GameObject blackPanel;
  public GameObject bullet;
  public GameObject cube;
  public GameObject miner;
  [Header("Resources")]
  public int lives;
  public int cubes;
  public bool turnBonus;
  [Header("Preferences")]
  public float checkRange;
  public float speed;
  public float turnSpeed;
  [Header("Levels")]
  public int damageLvl;
  public int wallsLvl;
  public int minerLvl;
  public int healLvl;
  public int actionLvl;
  [Header("Achievements")]
  public int kills;
  public int minersDestroyed;
  public int distanceGone;
  public int cubeMax;
  [Header("Actions")]
  public int actionNum;
  public bool isBusy;
  public bool isDead;
  public bool roflanMode;
  public int teamNum;
  private Vector3 turn;
  private Vector3 targetPosition;
  private Rigidbody rb;
  private Animator anim;
  private PlayerManager manager;
  private bool isMoving;
  private Collider[] playerForward;
  private Collider[] playerBehind;
  [SerializeField]
  public List<Miner> miners;

  private void Start()
  {
    this.rb = this.GetComponent<Rigidbody>();
    this.anim = this.GetComponent<Animator>();
    this.manager = GameObject.FindGameObjectWithTag("PlayerManager").GetComponent<PlayerManager>();
    this.manager.players.Add(this);
    this.midBodyPart.GetComponent<Renderer>().material = this.cubeMat;
    this.thirdBodyPart.GetComponent<Renderer>().material = this.GetComponentInChildren<Renderer>().material;
    this.ChangeHealth(0);
    this.UpdateColliders();
    this.manager.CheckPlayersCount();
    float x = (float) (1.0 + (double) this.nickname.text.Length * 1.1000000238418579);
    if ((double) x < 9.0)
      x = 9f;
    this.blackPanel.transform.localScale = new Vector3(x, this.blackPanel.transform.localScale.y, this.blackPanel.transform.localScale.z);
    if (!this.roflanMode)
      return;
    this.nickname.GetComponent<MeshRenderer>().enabled = false;
    this.nicknameShadow.GetComponent<MeshRenderer>().enabled = false;
  }

  private void Update()
  {
    if ((Object) this.nickname != (Object) null)
    {
      this.nickname.transform.LookAt(Camera.main.transform.position);
      this.nickname.transform.Rotate(0.0f, 180f, 0.0f);
    }
    if (this.isMoving && this.transform.position != this.targetPosition && this.groundIsForward)
    {
      this.transform.position = Vector3.MoveTowards(this.transform.position, this.targetPosition, this.speed * Time.deltaTime);
    }
    else
    {
      if ((!this.isMoving || !(this.transform.position == this.targetPosition)) && this.groundIsForward)
        return;
      this.isMoving = false;
      this.UpdateColliders();
    }
  }

  private void FixedUpdate()
  {
    Collider[] colliderArray1 = Physics.OverlapSphere(this.groundForwardPos.position, this.checkRange, (int) this.whatIsGround);
    Collider[] colliderArray2 = Physics.OverlapSphere(this.groundBehindPos.position, this.checkRange, (int) this.whatIsGround);
    groundIsForward = colliderArray1.Length != 0;
    groundIsBehind = colliderArray2.Length != 0;
    if (playerForward.Length != 0)
      groundIsForward = false;
    if (playerBehind.Length != 0)
      groundIsBehind = false;
    if (this.movingRight)
    {
      this.targetPosition = new Vector3(Mathf.Round(this.transform.position.x - 1f), this.transform.position.y, this.transform.position.z);
      this.StartCoroutine(this.MoveWaiter());
    }
    else if (this.movingLeft)
    {
      this.targetPosition = new Vector3(Mathf.Round(this.transform.position.x + 1f), this.transform.position.y, this.transform.position.z);
      this.StartCoroutine(this.MoveWaiter());
    }
    else if (this.movingBack)
    {
      this.targetPosition = new Vector3(this.transform.position.x, this.transform.position.y, Mathf.Round(this.transform.position.z + 1f));
      this.StartCoroutine(this.MoveWaiter());
    }
    else if (this.movingForward)
    {
      this.targetPosition = new Vector3(this.transform.position.x, this.transform.position.y, Mathf.Round(this.transform.position.z - 1f));
      this.StartCoroutine(this.MoveWaiter());
    }
    Scene activeScene;
    if (Input.GetKey(KeyCode.Q))
    {
      activeScene = SceneManager.GetActiveScene();
      SceneManager.LoadScene(activeScene.buildIndex + 1);
    }
    if (Input.GetKey(KeyCode.R))
    {
      activeScene = SceneManager.GetActiveScene();
      SceneManager.LoadScene(activeScene.buildIndex);
    }
    if (this.isRotating && this.turn != this.transform.localEulerAngles)
    {
      this.transform.rotation = Quaternion.RotateTowards(this.transform.rotation, Quaternion.Euler(this.turn), Time.deltaTime * this.turnSpeed);
    }
    else
    {
      if (!this.isRotating || !(this.turn == this.transform.localEulerAngles))
        return;
      this.isRotating = false;
    }
  }

  public void UpdateColliders()
  {
    this.playerForward = Physics.OverlapSphere(this.groundForwardPos.position, this.checkRange, (int) this.whatIsPlayer);
    this.playerBehind = Physics.OverlapSphere(this.groundBehindPos.position, this.checkRange, (int) this.whatIsPlayer);
  }

  public void UpdateCubes()
  {
    this.isBusy = false;
    this.turnBonus = false;
    this.turnText.text = "➜" + (this.actionLvl + 2).ToString();
    this.turnTextShadow.text = "➜" + (this.actionLvl + 2).ToString();
    this.ChangeCubes(1);
    foreach (Miner miner in this.miners)
    {
      if (!this.isBusy)
        miner.GiveCubes();
    }
    if (this.cubes <= this.cubeMax)
      return;
    this.cubeMax = this.cubes;
  }

  public void OnAnimUp()
  {
    if (!this.anim.GetCurrentAnimatorStateInfo(0).IsName("one") && !this.anim.GetCurrentAnimatorStateInfo(0).IsName("two"))
      return;
    this.anim.SetTrigger("up");
  }

  public void OnAnimDown()
  {
    this.readyToUpgrade = false;
    if (this.anim.GetCurrentAnimatorStateInfo(0).IsName("two"))
    {
      this.anim.SetTrigger("down");
    }
    else
    {
      if (!this.anim.GetCurrentAnimatorStateInfo(0).IsName("three"))
        return;
      this.anim.SetTrigger("down");
      this.StartCoroutine(this.DownAgain(false));
    }
  }

  public void OnTurnRight()
  {
    if (this.isBusy)
      return;
    this.turn = new Vector3(this.transform.localEulerAngles.x, Mathf.Round(this.transform.localEulerAngles.y + 90f), this.transform.localEulerAngles.z);
    this.StartCoroutine(this.OnRotation());
  }

  public void OnTurnLeft()
  {
    if (this.isBusy)
      return;
    this.turn = new Vector3(this.transform.localEulerAngles.x, Mathf.Round(this.transform.localEulerAngles.y - 90f), this.transform.localEulerAngles.z);
    this.StartCoroutine(this.OnRotation());
  }

  public void Shoot()
  {
    if (this.cubes <= this.damageLvl + 1)
      return;
    GameObject gameObject = Object.Instantiate<GameObject>(this.bullet, this.bulletPos.position, this.transform.rotation);
    Renderer component1 = gameObject.GetComponent<Renderer>();
    component1.material = this.cubeMat;
    Color color = component1.material.color;
    color = new Color(color.r - (float) this.damageLvl * 0.1f, color.g - (float) this.damageLvl * 0.1f, color.b - (float) this.damageLvl * 0.1f);
    component1.material.color = color;
    Bullet component2 = gameObject.GetComponent<Bullet>();
    component2.player = this;
    component2.damage = this.damageLvl + 1;
    component2.destroyEffect = this.destroyEffect;
    component2.lifetime = (float) ((double) (this.damageLvl + 2) * 0.21500000357627869 + 0.86000001430511475);
    component2.teamNum = this.teamNum;
    this.ChangeCubes(-(this.damageLvl + 1));
  }

  public void InstantiateCube()
  {
    if (this.cubes <= 0 || !this.groundIsBehind)
      return;
    this.MakeAction();
    this.ChangeCubes(-1);
    GameObject gameObject = Object.Instantiate<GameObject>(this.cube, new Vector3(Mathf.Round(this.groundBehindPos.position.x), Mathf.Round(this.groundBehindPos.position.y) + 1f, Mathf.Round(this.groundBehindPos.position.z)), Quaternion.identity);
    Renderer component1 = gameObject.GetComponent<Renderer>();
    component1.material = this.cubeMat;
    Color color = component1.material.color;
    color = new Color(color.r - (float) this.wallsLvl * 0.1f, color.g - (float) this.wallsLvl * 0.1f, color.b - (float) this.wallsLvl * 0.1f);
    component1.material.color = color;
    float num = Mathf.Pow((float) (this.wallsLvl + 1), 2f);
    CubeDurability component2 = gameObject.GetComponent<CubeDurability>();
    component2.durability = num + 1f;
    component2.startColor = this.cubeMat.color;
  }

  public void InstantiateMiner()
  {
    if (this.cubes < (this.minerLvl + 1) * 3 || !this.groundIsBehind)
      return;
    this.MakeAction();
    Miner component1 = Object.Instantiate<GameObject>(this.miner, new Vector3(Mathf.Round(this.groundBehindPos.position.x), Mathf.Round(this.groundBehindPos.position.y) + 1f, Mathf.Round(this.groundBehindPos.position.z)), Quaternion.identity).GetComponent<Miner>();
    component1.player = this;
    this.miners.Add(component1);
    Renderer component2 = component1.cube.GetComponent<Renderer>();
    component2.material = this.cubeMat;
    Color color = component2.material.color;
    color = new Color(color.r - (float) this.minerLvl * 0.1f, color.g - (float) this.minerLvl * 0.1f, color.b - (float) this.minerLvl * 0.1f);
    component2.material.color = color;
    component1.destroyEffect = this.destroyEffect;
    component1.OnAppear(this.minerLvl + 1);
    this.ChangeCubes(-(this.minerLvl + 1) * 3);
  }

  public void ChangeHealth(int changeValue)
  {
    if (this.lives + changeValue <= 100)
      this.lives += changeValue;
    else if (this.lives + changeValue > 100)
      this.lives = 100;
    this.hpText.text = "❤" + this.lives.ToString();
    this.hpTextShadow.text = "❤" + this.lives.ToString();
    if (this.lives > 0)
      return;
    this.gameObject.SetActive(false);
    this.isDead = true;
    if (this.teamNum != 0)
      --this.manager.teamMembers[this.teamNum - 1];
    this.manager.CheckPlayersCount();
  }

  public void ChangeCubes(int changeValue)
  {
    this.cubes += changeValue;
    this.cubeText.text = "❒" + this.cubes.ToString();
    this.cubeTextShadow.text = "❒" + this.cubes.ToString();
  }

  public void Upgrade()
  {
    this.OnAnimUp();
    this.readyToUpgrade = false;
    Object.Instantiate<GameObject>(this.upgradeEffect, this.thirdBodyPart.transform.position, Quaternion.identity);
    this.StartCoroutine(this.DownAgain(true));
  }

  public void OnHeal()
  {
    if (this.cubes < (this.healLvl + 1) * 3)
      return;
    this.ChangeHealth(this.healLvl + 1);
    this.ChangeCubes(-((this.healLvl + 1) * 3));
    Object.Instantiate<GameObject>(this.healEffect, this.midBodyPart.transform.position, Quaternion.identity);
  }

  private IEnumerator MoveWaiter()
  {
    this.UpdateColliders();
    WaitForSeconds waitForSeconds1 = new WaitForSeconds(0.1f);
    this.isMoving = true;
    WaitForSeconds waitForSeconds2 = new WaitForSeconds(1f);
    ++this.distanceGone;
    this.movingRight = false;
    this.movingLeft = false;
    this.movingBack = false;
    this.movingForward = false;
    yield return (object) null;
  }

  public void MakeAction()
  {
    this.isBusy = true;
    ++this.actionNum;
    if (!this.turnBonus)
    {
      TextMesh turnText = this.turnText;
      int num = this.actionLvl + 2 - this.actionNum;
      string str1 = "➜" + num.ToString();
      turnText.text = str1;
      TextMesh turnTextShadow = this.turnTextShadow;
      num = this.actionLvl + 2 - this.actionNum;
      string str2 = "➜" + num.ToString();
      turnTextShadow.text = str2;
    }
    else if (this.turnBonus)
    {
      this.turnText.text = "➜∞";
      this.turnTextShadow.text = "➜∞";
    }
    this.StartCoroutine(this.Action());
  }

  private IEnumerator Action()
  {
    yield return (object) new WaitForSeconds(0.2f);
    if (!this.turnBonus)
    {
      if (this.actionNum < this.actionLvl + 2)
        this.isBusy = false;
    }
    else if (this.turnBonus && this.actionNum < this.actionLvl + 10)
      this.isBusy = false;
  }

  private IEnumerator DownAgain(bool fromUp)
  {
    if (fromUp)
    {
      yield return (object) new WaitForSeconds(1f);
      this.anim.SetTrigger("down");
    }
    yield return (object) new WaitForSeconds(1f);
    this.anim.SetTrigger("down");
  }

  private IEnumerator OnRotation()
  {
    if (!this.isBusy)
    {
      this.isBusy = true;
      this.isRotating = true;
      yield return (object) new WaitForSeconds(0.4f);
      this.isBusy = false;
    }
  }

  private void OnTriggerEnter(Collider other)
  {
    if (!this.canTakeBonus)
      return;
    if (other.CompareTag("Heart"))
    {
      this.canTakeBonus = false;
      Object.Instantiate<GameObject>(this.healEffect, other.gameObject.transform.position, Quaternion.identity);
      Object.Destroy((Object) other.gameObject);
      this.ChangeHealth(10);
    }
    else if (other.CompareTag("Arrow"))
    {
      this.canTakeBonus = false;
      Object.Instantiate<GameObject>(this.destroyEffect, other.gameObject.transform.position, Quaternion.identity);
      Object.Destroy((Object) other.gameObject);
      this.turnBonus = true;
    }
    else if (other.CompareTag("CubeBonus"))
    {
      this.canTakeBonus = false;
      Object.Instantiate<GameObject>(this.destroyEffect, other.gameObject.transform.position, Quaternion.identity);
      Object.Destroy((Object) other.gameObject);
      this.ChangeCubes(5);
    }
    else
    {
      if (!other.CompareTag("Dead"))
        return;
      Object.Instantiate<GameObject>(this.destroyEffect, this.gameObject.transform.position, Quaternion.identity);
      this.ChangeHealth(-10000);
    }
  }
}
