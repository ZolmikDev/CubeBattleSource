﻿// Decompiled with JetBrains decompiler
// Type: PlayerManager
// Assembly: Assembly-CSharp-firstpass, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F854CF76-F23B-40C3-B0EB-CA9D6F42F62C
// Assembly location: D:\Games\CubeBattle\CubeBattle_Data\Managed\Assembly-CSharp-firstpass.dll

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerManager : MonoBehaviour
{
  public List<PlayerSpawner> spawners;
  public List<PlayerController> players;
  public Material[] firstMaterials;
  public Material[] cubeMaterials;
  public GameObject[] destroyEffects;
  public Material[] teamFirstMaterials;
  public Material[] teamCubeMaterials;
  public GameObject[] teamDestroyEffects;
  public GameObject[] bonuses;
  public DiscordManager discordManager;
  public Camera cam;
  public GameObject[] levels;
  public Vector3[] cameraPoses;
  public Text turnText;
  public Text playersLeft;
  public Text zoneText;
  public Text playerWait;
  public Text timeWait;
  public GameObject[] panel;
  public Animator anim;
  public Text countdown;
  public Text winnerText;
  public Text killerText;
  public Text minerText;
  public Text travellerText;
  public Text cubeText;
  public Text winnerSecond;
  public Text pointsText;
  public Text[] teamTexts;
  public GameObject winPanel;
  public bool warned;
  private bool onStart = true;
  private bool onWarn;
  public int secondsLeft = 60;
  public int camPos;
  public int playersCount;
  public int maxKillsNum;
  public string maxKillsNick;
  public int maxMinersNum;
  public string maxMinersNick;
  public int maxDistanceNum;
  public string maxDistanceNick;
  public int maxCubesNum;
  public string maxCubesNick;
  public int[] teamMembers;
  public bool roflanMode;

  private void OnEnable()
  {
    this.discordManager = Object.FindObjectOfType<DiscordManager>();
    this.discordManager.manager = this;
    this.CheckPlayersCount();
    this.teamMembers = new int[this.discordManager.teamNum];
    for (int index = 0; index < this.teamMembers.Length; ++index)
      this.teamTexts[index].gameObject.SetActive(true);
  }

  public void OnRoflanMode()
  {
    this.roflanMode = true;
    Debug.Log((object) "прикол работает");
  }

  public void OnNewPlayerSpawn(string nickname, int materialNum)
  {
    int index = Random.Range(0, this.spawners.Count - 1);
    if (this.spawners[index].canSpawn)
    {
      if (!this.roflanMode)
      {
        this.spawners[index].SpawnPlayer(nickname, this.firstMaterials[materialNum], this.cubeMaterials[materialNum], this.destroyEffects[materialNum], 0);
      }
      else
      {
        if (!this.roflanMode)
          return;
        this.spawners[index].SpawnPlayer(nickname, this.firstMaterials[6], this.cubeMaterials[6], this.destroyEffects[6], 0);
      }
    }
    else
      this.OnNewPlayerSpawn(nickname, materialNum);
  }

  public void OnTeamPlayerSpawn(string nickname)
  {
    int num = Mathf.Min(this.teamMembers);
    for (int index1 = 0; index1 < this.teamMembers.Length; ++index1)
    {
      if (this.teamMembers[index1] == num)
      {
        int index2 = Random.Range(0, this.spawners.Count - 1);
        if (this.spawners[index2].canSpawn)
        {
          this.spawners[index2].SpawnPlayer(nickname, this.teamFirstMaterials[index1], this.teamCubeMaterials[index1], this.teamDestroyEffects[index1], index1 + 1);
          ++this.teamMembers[index1];
          break;
        }
        this.OnTeamPlayerSpawn(nickname);
        break;
      }
    }
  }

  public void OnTestSpawn()
  {
    if (this.discordManager.teamNum != 0)
    {
      this.OnTeamPlayerSpawn("ку, лол");
    }
    else
    {
      if (this.discordManager.teamNum != 0)
        return;
      int index = Random.Range(0, this.spawners.Count - 1);
      if (this.spawners[index].canSpawn)
        this.spawners[index].SpawnTest();
      else
        this.OnTestSpawn();
    }
  }

  public void CheckPlayersCount()
  {
    if (this.teamMembers.Length != 0)
      this.UpdateTeamTexts();
    this.playersCount = 0;
    for (int index = 0; index < this.players.Count; ++index)
    {
      if (!this.players[index].isDead)
        ++this.playersCount;
    }
    this.playerWait.text = "Набор игроков: " + this.playersCount.ToString();
    this.playersLeft.text = "Осталось игроков: " + this.playersCount.ToString();
    if (this.playersCount < 3 && this.onStart)
    {
      if (!this.levels[1].activeInHierarchy)
      {
        this.levels[1].SetActive(true);
        this.cam.transform.position = this.cameraPoses[0];
        this.camPos = 0;
      }
    }
    else if (this.playersCount < 6 && this.onStart)
    {
      if (!this.levels[2].activeInHierarchy)
      {
        this.levels[2].SetActive(true);
        this.cam.transform.position = this.cameraPoses[1];
        this.camPos = 1;
      }
    }
    else if (this.playersCount < 15 && this.onStart)
    {
      if (!this.levels[3].activeInHierarchy)
      {
        this.levels[3].SetActive(true);
        this.cam.transform.position = this.cameraPoses[2];
        this.camPos = 2;
      }
    }
    else if (this.playersCount < 22 && this.onStart)
    {
      if (!this.levels[4].activeInHierarchy)
      {
        this.levels[4].SetActive(true);
        this.cam.transform.position = this.cameraPoses[3];
        this.camPos = 3;
      }
    }
    else if (this.playersCount < 47 && this.onStart)
    {
      if (!this.levels[5].activeInHierarchy)
      {
        this.levels[5].SetActive(true);
        this.cam.transform.position = this.cameraPoses[4];
        this.camPos = 4;
      }
    }
    else if (this.playersCount > 47 && this.onStart && !this.levels[6].activeInHierarchy)
    {
      this.levels[6].SetActive(true);
      this.cam.transform.position = this.cameraPoses[5];
      this.camPos = 5;
    }
    if (!this.onStart && this.playersCount == 1 && this.teamMembers.Length == 0)
    {
      this.winPanel.SetActive(true);
      this.OnGameOver();
      foreach (PlayerController player in this.players)
      {
        if (!player.isDead)
          this.winnerText.text = player.nickname.text;
      }
    }
    else
    {
      if (this.onStart || this.teamMembers.Length == 0)
        return;
      int num = 0;
      for (int index = 0; index < this.teamMembers.Length; ++index)
      {
        if (this.teamMembers[index] != 0)
          ++num;
      }
      if (num > 1)
        return;
      this.winPanel.SetActive(true);
      this.OnGameOver();
      foreach (PlayerController player in this.players)
      {
        if (!player.isDead)
        {
          this.winnerSecond.text = "Выиграли:";
          this.pointsText.gameObject.SetActive(false);
          if (player.teamNum == 1)
          {
            this.winnerText.text = "Красные";
            break;
          }
          if (player.teamNum == 2)
          {
            this.winnerText.text = "Зелёные";
            break;
          }
          if (player.teamNum == 3)
          {
            this.winnerText.text = "Голубые";
            break;
          }
          if (player.teamNum == 4)
          {
            this.winnerText.text = "Жёлтые";
            break;
          }
          if (player.teamNum == 5)
          {
            this.winnerText.text = "Оранжевые";
            break;
          }
          if (player.teamNum == 6)
          {
            this.winnerText.text = "Розовые";
            break;
          }
          if (player.teamNum != 7)
            break;
          this.winnerText.text = "Фиолетовые";
          break;
        }
      }
    }
  }

  public void UpdateTeamTexts()
  {
    for (int index = 0; index < this.teamMembers.Length; ++index)
    {
      if (this.teamTexts[index].text.Contains("Красные"))
        this.teamTexts[index].text = "Красные: " + this.teamMembers[index].ToString();
      else if (this.teamTexts[index].text.Contains("Зелёные"))
        this.teamTexts[index].text = "Зелёные: " + this.teamMembers[index].ToString();
      if (this.teamTexts[index].text.Contains("Голубые"))
        this.teamTexts[index].text = "Голубые: " + this.teamMembers[index].ToString();
      if (this.teamTexts[index].text.Contains("Жёлтые"))
        this.teamTexts[index].text = "Жёлтые: " + this.teamMembers[index].ToString();
      if (this.teamTexts[index].text.Contains("Оранжевые"))
        this.teamTexts[index].text = "Оранжевые: " + this.teamMembers[index].ToString();
      if (this.teamTexts[index].text.Contains("Розовые"))
        this.teamTexts[index].text = "Розовые: " + this.teamMembers[index].ToString();
      if (this.teamTexts[index].text.Contains("Фиолетовые"))
        this.teamTexts[index].text = "Фиолетовые: " + this.teamMembers[index].ToString();
    }
  }

  public void SpawnBonuses()
  {
    this.turnText.text = "Ход #" + this.discordManager.turnNum.ToString();
    if (this.discordManager.turnNum % 30 == 0)
      this.warned = true;
    this.WarnZoneFall();
    foreach (PlayerSpawner spawner in this.spawners)
    {
      if (spawner.canSpawn)
      {
        int index = Random.Range(0, 1500);
        switch (index)
        {
          case 0:
            Object.Instantiate<GameObject>(this.bonuses[0], new Vector3(spawner.transform.position.x, spawner.transform.position.y - 3f, spawner.transform.position.z), Quaternion.identity);
            spawner.canSpawn = false;
            continue;
          case 1:
          case 2:
            Vector3 position = new Vector3(spawner.transform.position.x, spawner.transform.position.y - 3f, spawner.transform.position.z);
            Object.Instantiate<GameObject>(this.bonuses[index], position, Quaternion.identity);
            spawner.canSpawn = false;
            continue;
          default:
            continue;
        }
      }
    }
  }

  public void WarnZoneFall()
  {
    if (!this.warned)
      return;
    if (!this.zoneText.gameObject.activeInHierarchy)
    {
      this.zoneText.gameObject.SetActive(true);
      this.zoneText.text = "Уменьшение зоны через 3 хода!";
      for (int index = 0; index < this.levels.Length - 1; ++index)
      {
        if (this.levels[index].activeInHierarchy && !this.levels[index + 1].activeInHierarchy)
        {
          foreach (PlayerSpawner spawner in this.spawners)
          {
            if (spawner.transform.parent.parent.parent.name == this.levels[index].name)
              this.StartCoroutine(this.TransparentZone(spawner));
          }
        }
        else if (this.levels[6].activeInHierarchy)
        {
          foreach (PlayerSpawner spawner in this.spawners)
          {
            if (spawner.transform.parent.parent.parent.name == this.levels[6].name)
              this.StartCoroutine(this.TransparentZone(spawner));
          }
        }
      }
    }
    else if (this.zoneText.text.Contains("3"))
      this.zoneText.text = "Уменьшение зоны через 2 хода!";
    else if (this.zoneText.text.Contains("2"))
      this.zoneText.text = "Уменьшение зоны через 1 ход!";
    else if (this.zoneText.text.Contains("1"))
    {
      this.zoneText.text = "Уменьшение зоны!";
      --this.camPos;
      this.ZoneFall();
    }
    else
    {
      if (!(this.zoneText.text == "Уменьшение зоны!"))
        return;
      this.warned = false;
      this.zoneText.gameObject.SetActive(false);
    }
  }

  public void ZoneFall()
  {
    for (int index = 0; index < this.levels.Length - 1; ++index)
    {
      if (this.levels[index].activeInHierarchy && !this.levels[index + 1].activeInHierarchy)
      {
        foreach (PlayerSpawner spawner in this.spawners)
        {
          if (spawner.transform.parent.parent.parent.name == this.levels[index].name)
          {
            spawner.OnZoneFall();
            this.StartCoroutine(this.ZoneDeactivate(this.levels[index]));
          }
        }
      }
      else if (this.levels[6].activeInHierarchy)
      {
        foreach (PlayerSpawner spawner in this.spawners)
        {
          if (spawner.transform.parent.parent.parent.name == this.levels[6].name)
          {
            spawner.OnZoneFall();
            this.StartCoroutine(this.ZoneDeactivate(this.levels[6]));
          }
        }
      }
    }
  }

  public IEnumerator TransparentZone(PlayerSpawner spawner)
  {
    Renderer rend = spawner.GetComponentInParent<Renderer>();
    Color oldColor = rend.material.color;
    Color newColor = new Color(oldColor.r, oldColor.g, oldColor.b, 0.8f);
    while (spawner.gameObject.activeInHierarchy)
    {
      rend.material.color = newColor;
      yield return (object) new WaitForSeconds(1f);
      rend.material.color = oldColor;
      yield return (object) new WaitForSeconds(1f);
    }
  }

  public void MinusSeconds()
  {
    --this.secondsLeft;
    if (this.secondsLeft >= 10)
      this.timeWait.text = "00:" + this.secondsLeft.ToString();
    else if (this.secondsLeft > 3)
    {
      this.timeWait.text = "00:0" + this.secondsLeft.ToString();
    }
    else
    {
      if (this.secondsLeft != 3)
        return;
      this.StartCoroutine(this.GameStart());
    }
  }

  public void OnGameOver()
  {
    for (int index = 0; index < this.players.Count; ++index)
    {
      if (this.players[index].kills > this.maxKillsNum)
      {
        this.maxKillsNum = this.players[index].kills;
        this.maxKillsNick = this.players[index].nickname.text;
      }
      if (this.players[index].minersDestroyed > this.maxMinersNum)
      {
        this.maxMinersNum = this.players[index].minersDestroyed;
        this.maxMinersNick = this.players[index].nickname.text;
      }
      if (this.players[index].distanceGone > this.maxDistanceNum)
      {
        this.maxDistanceNum = this.players[index].distanceGone;
        this.maxDistanceNick = this.players[index].nickname.text;
      }
      if (this.players[index].cubeMax > this.maxCubesNum)
      {
        this.maxCubesNum = this.players[index].cubeMax;
        this.maxCubesNick = this.players[index].nickname.text;
      }
      ++this.playersCount;
    }
    this.DisplayWinners();
  }

  public void DisplayWinners()
  {
    this.killerText.text = this.maxKillsNick + " - сделал " + this.maxKillsNum.ToString() + " убийств";
    this.minerText.text = this.maxMinersNick + " - сломал " + this.maxMinersNum.ToString() + " майнеров";
    this.travellerText.text = this.maxDistanceNick + " - прошёл " + this.maxDistanceNum.ToString() + " клеток";
    this.cubeText.text = this.maxCubesNick + " - накопил " + this.maxCubesNum.ToString() + " кубов";
  }

  public IEnumerator ZoneDeactivate(GameObject zone)
  {
    yield return (object) new WaitForSeconds(3f);
    zone.SetActive(false);
    this.cam.transform.position = this.cameraPoses[this.camPos];
  }

  public IEnumerator GameStart()
  {
    this.anim.SetBool("start", true);
    this.countdown.gameObject.SetActive(true);
    yield return (object) new WaitForSeconds(1f);
    this.countdown.text = "2";
    yield return (object) new WaitForSeconds(1f);
    this.countdown.text = "1";
    yield return (object) new WaitForSeconds(1f);
    this.countdown.text = "BATTLE!";
    yield return (object) new WaitForSeconds(1f);
    this.panel[0].SetActive(false);
    this.panel[1].SetActive(true);
    this.onStart = false;
  }
}
