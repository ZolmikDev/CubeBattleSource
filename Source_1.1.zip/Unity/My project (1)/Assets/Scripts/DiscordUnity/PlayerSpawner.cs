﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000020 RID: 32
public class PlayerSpawner : MonoBehaviour
{
	// Token: 0x060000E5 RID: 229 RVA: 0x00006994 File Offset: 0x00004B94
	private void Start()
	{
		this.manager = GameObject.FindGameObjectWithTag("PlayerManager").GetComponent<PlayerManager>();
		if (base.gameObject.activeInHierarchy)
		{
			this.canSpawn = true;
			this.manager.spawners.Add(this);
			return;
		}
		this.canSpawn = false;
		base.StartCoroutine(this.WaitForEnable());
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x000069F0 File Offset: 0x00004BF0
	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("Player"))
		{
			this.canSpawn = false;
			base.GetComponentInParent<Renderer>().material.color = other.GetComponentInChildren<Renderer>().material.color;
		}
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x00006A28 File Offset: 0x00004C28
	private void OnTriggerExit(Collider other)
	{
		if (other.CompareTag("Player"))
		{
			this.canSpawn = true;
		}
		if (other.CompareTag("Heart") || other.CompareTag("Arrow") || other.CompareTag("CubeBonus"))
		{
			UnityEngine.Object.Destroy(other.gameObject);
		}
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x00006A7C File Offset: 0x00004C7C
	public void SpawnPlayer(string nickname, Material material, Material lightMaterial, GameObject destroyEffect, int teamNum)
	{
		GameObject gameObject = UnityEngine.Object.Instantiate<GameObject>(this.player, base.transform.position, Quaternion.identity);
		PlayerController component = gameObject.GetComponent<PlayerController>();
		gameObject.GetComponentInChildren<Renderer>().material = material;
		component.cubeMat = lightMaterial;
		component.nickname.text = nickname;
		component.nicknameShadow.text = nickname;
		component.cubeText.color = lightMaterial.color;
		component.destroyEffect = destroyEffect;
		component.teamNum = teamNum;
		component.roflanMode = this.manager.roflanMode;
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x00006B08 File Offset: 0x00004D08
	public void SpawnTest()
	{
		PlayerController component = UnityEngine.Object.Instantiate<GameObject>(this.player, base.transform.position, Quaternion.identity).GetComponent<PlayerController>();
		component.nickname.text = "nickname";
		component.nicknameShadow.text = "nickname";
	}

	// Token: 0x060000EA RID: 234 RVA: 0x00006B54 File Offset: 0x00004D54
	public IEnumerator WaitForEnable()
	{
		new WaitUntil(() => base.gameObject.activeInHierarchy);
		this.manager.spawners.Add(this);
		yield return null;
		yield break;
	}

	// Token: 0x060000EB RID: 235 RVA: 0x00006B63 File Offset: 0x00004D63
	public void OnZoneFall()
	{
		base.transform.parent.gameObject.AddComponent<Rigidbody>();
		this.canSpawn = false;
	}

	// Token: 0x040000A2 RID: 162
	public GameObject player;

	// Token: 0x040000A3 RID: 163
	public bool canSpawn = true;

	// Token: 0x040000A4 RID: 164
	private PlayerManager manager;
}
