﻿// Decompiled with JetBrains decompiler
// Type: TeamNumChange
// Assembly: Assembly-CSharp-firstpass, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F854CF76-F23B-40C3-B0EB-CA9D6F42F62C
// Assembly location: D:\Games\CubeBattle\CubeBattle_Data\Managed\Assembly-CSharp-firstpass.dll

using UnityEngine;
using UnityEngine.UI;

public class TeamNumChange : MonoBehaviour
{
  public Text teamText;
  public DiscordManager discordManager;
  public int teamNum = 2;

  public void OnActivate() => this.discordManager.teamNum = this.teamNum;

  public void OnDeactivate() => this.discordManager.teamNum = 0;

  public void OnLeftButtonDown()
  {
    if (this.teamNum <= 2)
      return;
    --this.teamNum;
    this.teamText.text = this.teamNum.ToString();
    this.discordManager.teamNum = this.teamNum;
  }

  public void OnRightButtonDown()
  {
    if (this.teamNum >= 7)
      return;
    ++this.teamNum;
    this.teamText.text = this.teamNum.ToString();
    this.discordManager.teamNum = this.teamNum;
  }
}
