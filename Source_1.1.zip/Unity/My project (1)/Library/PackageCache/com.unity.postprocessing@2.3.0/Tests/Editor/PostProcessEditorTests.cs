using NUnit.Framework;

class PostProcessEditorTests
{
    [Test]
    public void DummyTest()
    {
        Assert.IsTrue(true);
    }
}
